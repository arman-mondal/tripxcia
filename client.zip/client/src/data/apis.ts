import { API_URL } from "@/configs/api";

export const SaveFlight=API_URL+"query/flight/save";
export const GetFlightQueries=API_URL+"query/flight/list";
export const ConfirmFlightQuery=API_URL+"query/flight/confirm/";
export const CreateClient=API_URL+"clients/create";
export const GetClients=API_URL+"clients/get";
export const DeleteClient=API_URL+"clients/delete/";
export const UpdateClient=API_URL+"clients/update/";