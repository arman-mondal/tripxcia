import { Router } from "express";
import { QueryRoutes } from "./app/query/query.routes";
import { clientRouter } from "./app/clients/client.routes";

const app=Router();

app.use('/query',QueryRoutes);
app.use('/clients',clientRouter);

export{
    app as Router
}